function showNum(randomX,randomY,randomNum){
	//console.log('1');
	var numCell = $('#number-cell-'+randomX+'-'+randomY);

	numCell.css('background-color',getNumBgColor(randomNum));
	numCell.css('color',getNumColor(randomNum));
	numCell.text(randomNum);

	numCell.animate({
		width:'100px',
		height:'100px',
		top:getTop(randomX,randomY),
		left:getLeft(randomX,randomY)
	},50);
}

function move2L(i,j,k,num){
	var numCell = $('number-cell-'+i+'-'+j);
	numCell.text(num);
	numCell.animate({
		top: getTop(i,k),
		left: getLeft(i,k)
	});
}